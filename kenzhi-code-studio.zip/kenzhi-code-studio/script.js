let editor

require.config({
paths:{vs:'https://cdn.jsdelivr.net/npm/monaco-editor@0.34.1/min/vs'}
})

require(["vs/editor/editor.main"],function(){

editor = monaco.editor.create(document.getElementById("editor"),{

value:"<h1>KENZHI CODE STUDIO</h1>",
language:"html",
theme:"vs-dark",
automaticLayout:true

})

})

function runCode(){

let code = editor.getValue()

document.getElementById("frame").srcdoc = code

}

function newFile(){

let name = prompt("File name")

let li = document.createElement("li")

li.innerText = name

document.getElementById("fileList").appendChild(li)

}

function downloadProject(){

let code = editor.getValue()

let blob = new Blob([code])

let a = document.createElement("a")

a.href = URL.createObjectURL(blob)

a.download = "index.html"

a.click()

}

function toggleAI(){

let panel = document.getElementById("aiPanel")

panel.style.display = panel.style.display==="flex"?"none":"flex"

}

async function askAI(){

let text = document.getElementById("aiInput").value

let res = await fetch("/ai",{

method:"POST",

headers:{
"Content-Type":"application/json"
},

body:JSON.stringify({
message:text
})

})

let data = await res.json()

let reply = data.choices[0].message.content

document.getElementById("aiMessages").innerHTML +=
"<p>🤖 "+reply+"</p>"

}