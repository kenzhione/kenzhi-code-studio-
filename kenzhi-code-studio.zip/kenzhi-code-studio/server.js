const express = require("express")
const fetch = require("node-fetch")

const app = express()

app.use(express.json())
app.use(express.static("."))

const API_KEY = "sk-UHXAKeXCp_f2GnoVS0dkYg"

app.post("/ai", async (req, res) => {

let message = req.body.message

let response = await fetch("https://api.openai.com/v1/chat/completions", {

method: "POST",

headers: {
"Content-Type": "application/json",
"Authorization": "Bearer " + API_KEY
},

body: JSON.stringify({
model: "gpt-4.1-mini",
messages: [
{ role: "user", content: message }
]
})

})

let data = await response.json()

res.json(data)

})

app.listen(3000, () => {

console.log("KENZHI CODE STUDIO running")

})